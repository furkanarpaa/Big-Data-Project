#!/usr/bin/env python
import sys
from collections import defaultdict

# Default dictionary to hold aggregated data
data = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))

# Loop through the input line by line
for line in sys.stdin:
    line = line.strip()
    country, customer_segment, month, product_category, product_brand, shipment_method, payment_method = line.split('\t')

    # Store data in a structured way for analysis
    data[country][customer_segment][month].append((product_category, product_brand, shipment_method, payment_method))

# Output the aggregated data
for country, segments in data.items():
    for segment, months in segments.items():
        for month, products in months.items():
            # Output format: Country, Customer Segment, Month, Products
            print(f"{country}\t{segment}\t{month}\t{len(products)}")
