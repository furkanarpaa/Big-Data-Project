
#!/usr/bin/env python
import sys

# Loop through the input line by line
for line in sys.stdin:
    line = line.strip()
    
    # Split the line into columns
    columns = line.split(',')
    
    # Skip header
    if columns[0] == "Country":
        continue

    # Extract relevant columns
    country = columns[9]
    age = columns[10]
    customer_segment = columns[13]
    month = columns[16]
    product_category = columns[21]
    product_brand = columns[22]
    shipment_method = columns[25]
    payment_method = columns[26]
    product = columns[29]

    # Emit relevant data for analysis
    print(f"{country}\t{customer_segment}\t{month}\t{product_category}\t{product_brand}\t{shipment_method}\t{payment_method}")

